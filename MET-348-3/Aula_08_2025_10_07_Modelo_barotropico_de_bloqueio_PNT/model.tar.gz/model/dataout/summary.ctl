dset ^summary.dat
options little_endian
undef 9.999E+20
title CDAS data
xdef 128 linear   0  2.8125
ydef  64 levels
 -87.8638 -85.0965 -82.3129 -79.5256 -76.7369 -73.9475 
 -71.1577 -68.3678 -65.5776 -62.7873 -59.9970 -57.2066 
 -54.4162 -51.6257 -48.8352 -46.0447 -43.2542 -40.4636 
 -37.6731 -34.8825 -32.0919 -29.3014 -26.5108 -23.7202 
 -20.9296 -18.1390 -15.3484 -12.5578 -9.7671 -6.9765 
 -4.1859  -1.3953 1.3953 4.1859 6.9765 9.7671 12.5578 
  15.3484 18.1390 20.9296 23.7202 26.5108 29.3014  
  32.0919 34.8825 37.6731 40.4636 43.2542 46.0447 
  48.8352 51.6257 54.4162 57.2066 59.9970 62.7873 
  65.5776 68.3678 71.1577 73.9475 76.7369 79.5256 
  82.3129 85.0965 87.8638 
tdef 4225 linear 01jan2007 1dy
zdef 1 levels 500
vars 6
forceg   0 99 forcing
vortbarg 0 99 conditions to summary file
psibarg  0 99 conditions to summary file
ubarg    0 99 conditions to summary file
vbarg    0 99 conditions to summary file
hgtg     0 99 conditions to summary file
endvars
