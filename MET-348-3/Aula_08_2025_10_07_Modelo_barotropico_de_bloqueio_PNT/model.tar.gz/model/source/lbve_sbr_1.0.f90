!C
!C  Fortran 77 program to solve the linearized barotropic
!C  vorticity equation on the sphere, for idealized ENSO forcing and
!C  a basic state of solid body rotation, following:
!C
!C  Branstator, G., 1985: Analysis of General Circulation Model
!C  Sea-Surface Temperature Anomaly Simulations Using a Linear 
!C  Model. Part I: Forced Solutions. J. Atmos. Sci., 42, 2225–2241.
!C
!C  Coded by Matt Barlow, in my youth, to learn how spectral models
!C  work.  If you find any errors, please send me
!C  an email at Mathew_Barlow@uml.edu.
!C
!C  CAUTION: has not been extensively tested but could be compared
!C  to Fig. 5a in Branstator (1985). 
!C
!C  NOTES:
!C
!C  Global spectral barotropic model with triangular truncation.
!C  Currently set to T21 but runs at T42.
!C
!C  Maximum wave number and grid dimensions set separately, 
!C  up to the user to ensure the correct relationship
!C
!C  Variables ending in 's' are spherical harmonic (spectral) 
!C  coefficients and variables ending in 'g' are gridded values
!C
!C  For time differencing, vorticity at the current time is 'vort',
!C  vorticity at the previous time is 'oldvort', and vorticity
!C  at the next time is 'newvort'
!C
!C  Single index, ik, for coefficients for convenience, related to
!C  the indices of the SHs by ik=1+(l+1)*l-m
!C
!C  Keeps more waves than the maximum triangular truncation, for
!C  calculation of the meridional derivative.  For convenience, all
!C  coefficients have these extra waves, although they're only used
!C  for the calcuation of the meridional derivative
!C
!C  The standard transform to U=u*cos(lat) and V=v*cos(lat) is not 
!C  made here, to keep the code simple.  See ddx and ddy subroutines
!C  for more discussion.
!C
!C  Throughout, "SH" = spherical harmonic.
!C
        implicit none
        integer lmax,nx,ny,nk,nk2,nt,fwdskip,outskip
        real pi,re,dt,omega,r
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(r=-1.0/(60.0*60.0*24.0*7.0)) ! drag coefficient
        parameter(pi=3.1415927)
        parameter(re=6.371e6)
        parameter(omega=7.292E-5)
!
        parameter(dt=60.0*60.0) ! time step
        parameter(nt=24*21)        ! number of times
!
        parameter(fwdskip=10) ! how often to use a forward time step
        parameter(outskip=1)  ! how often to write output
!
        real lats(ny),w(ny)
        real vortg(nx,ny),vorts(nk2),psig(nx,ny),psis(nk2)
        real varg(nx,ny),vars(nk2)
        real ddyg(nx,ny),ddxg(nx,ny)
        real fac,eta,lat,etalp1,rlp1,rm,rl,rlp2,rlm1
        real ddxvortg(nx,ny),ddyvortg(nx,ny)
        real advecg(nx,ny),advecs(nk2)
        real newvorts(nk2),oldvorts(nk2)
        real ug(nx,ny),vg(nx,ny),beta(ny)
        real alp(nk2,ny),diffs(nk2)
        real hgtg(nx,ny)
!
        real vortbarg(nx,ny),ubarg(nx,ny),vbarg(nx,ny)
        real vortbars(nk2),psibars(nk2),psibarg(nx,ny)
        real ddxvortbarg(nx,ny),ddyvortbarg(nx,ny)
        real ubars(nk2)
!
        real forceg(nx,ny),forces(nk2)
!
        integer l,m,ik,ik2,ix,iy,iklp1,iklm1,it
        integer irec
        psig=0.0
!
! open input and output files
!
!
! NB: this file can be used to read in the basic state
! for cases other than solid body rotation
!
!        open(13,file='vortT42.dat',access='direct',
!     &    recl=nx*ny*4,status='old')
!
! output
!
        open(14,file='../dataout/forecast.dat',access='direct',  &
     &    recl=nx*ny*4,status='unknown')
!
! summary of output
!
        open(15,file='../dataout/summary.dat',access='direct', &
     &    recl=nx*ny*4,status='unknown')
!
! calculate Gaussian latitudes and weights, and 
! Associated Legendre Polynomials (ALPs) ahead of time
!
        call makegauss(w,lats,alp)
!
!  set forcing
!
        call makeforce(forceg,forces,alp,w,lats)
!
!
!  set up basic state: solid body rotation
!
        do ix=1,nx
        do iy=1,ny
           lat=lats(iy)*pi/180.0
           ubarg(ix,iy)=14.0*cos(lat)
        enddo
        enddo
!
        call grid2specfft(ubarg,ubars,alp,w)
        call ddyfft(-ubars,vortbarg,alp,w,lats)
        do ix=1,nx
        do iy=1,ny
           lat=lats(iy)*pi/180.0
           vortbarg(ix,iy)=vortbarg(ix,iy)+ubarg(ix,iy)*tan(lat)/re
        enddo
        enddo
        call grid2specfft(vortbarg,vortbars,alp,w)
        call vort2psi(vortbars,psibars)
        call spec2gridfft(psibars,psibarg,alp)
        call ddxfft(vortbars,ddxvortbarg,alp,w,lats)
        call ddyfft(vortbars,ddyvortbarg,alp,w,lats)
!
!  set intial conditions (spectral coefficients of vorticity)
!
        do ix=1,nx
        do iy=1,ny
           vortg(ix,iy)=0.0
        enddo
        enddo
        call grid2specfft(vortg,vorts,alp,w)
!
!
!  write out forcing and initial conditions to summary file
!
        write(15,rec=1)forceg
        write(15,rec=2)vortbarg
        write(15,rec=3)psibarg
        write(15,rec=4)ubarg
        write(15,rec=5)vbarg
        call psi2hgt(psis,hgtg,alp,w,lats)
        write(15,rec=8)hgtg
!
!  set up beta (df/dy)
!
        do iy=1,ny
            lat=lats(iy)*pi/180.0
            beta(iy)=2.0*omega*cos(lat)/re
        enddo
!
print*,'pasei'
        irec=1
!
! START TIME-STEPPING
!
        do it=1,nt
print*,'pasei 1 '

           write(6,'(A9,I4,A4,I4)')'timestep ',it,' of ',nt 
print*,'pasei 2',maxval(psig),minval(psig)

!
!  current vorticity is spectral:  vorts
!
!
!  calculate diffusion
!
           call makediff(vorts,diffs)
!
!  calculate advection, starting with spectral values and ending with
!  spectral values, but doing multiplication on the grid
!
           call vort2psi(vorts,psis)
           call ddyfft(psis,ug,alp,w,lats)
           do ix=1,nx
           do iy=1,ny
              ug(ix,iy)=-ug(ix,iy)
           enddo
           enddo
           call ddxfft(psis,vg,alp,w,lats)
           call ddxfft(vorts,ddxvortg,alp,w,lats)
           call ddyfft(vorts,ddyvortg,alp,w,lats)
           do ix=1,nx
           do iy=1,ny
              advecg(ix,iy)=                    &
     &            -ubarg(ix,iy)*ddxvortg(ix,iy) &
     &            -vbarg(ix,iy)*ddyvortg(ix,iy) &
     &            -ug(ix,iy)*ddxvortbarg(ix,iy) &
     &            -vg(ix,iy)*ddyvortbarg(ix,iy) &
     &            -beta(iy)*vg(ix,iy)
           enddo
           enddo
           call grid2specfft(advecg,advecs,alp,w)

!
           if(mod(it-1,fwdskip).eq.0)then
!
!  forward difference time step, spectral
!
              do ik=1,nk2
                newvorts(ik)=                  &
     &              vorts(ik)+dt*advecs(ik)    &
     &            + dt*(r*vorts(ik)+diffs(ik)) &
     &            + dt*forces(ik)

              enddo
!
           else
!
!  center difference time step, spectral
!
              do ik=1,nk2
                newvorts(ik)=                       &
     &              oldvorts(ik)+2.0*dt*advecs(ik)  &
     &            + 2.0*dt*(r*vorts(ik)+diffs(ik))  &
     &            + 2.0*dt*forces(ik)

              enddo

           endif
!
!  write out values along the way
!
           if(mod(it-1,outskip).eq.0.or.it.eq.nt)then
               call spec2gridfft(vorts,vortg,alp)
               write(14,rec=irec)vortg
               irec=irec+1
               call vort2psi(vorts,psis)
               call spec2gridfft(psis,psig,alp)
               write(14,rec=irec)psig
               irec=irec+1
           endif
!
!  update variables (in terms of spectral coefficients)
!
           do ik=1,nk2
             oldvorts(ik)=vorts(ik)
             vorts(ik)=newvorts(ik)
           enddo
!
        enddo
!
!  TIME-STEPPING DONE
!
!
!  write out to summary file
!
        call spec2gridfft(newvorts,vortg,alp)
        write(15,rec=6)vortg
        call vort2psi(vorts,psis)
        call spec2gridfft(psis,psig,alp)
        write(15,rec=7)psig
        call psi2hgt(psis,hgtg,alp,w,lats)
        write(15,rec=8)hgtg
!
!
        stop
        end
!
!
!
        subroutine makegauss(w,lats,alp)
!
        integer lmax,nx,ny,nk,nk2
        real pi
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
!
        real lats(ny),lat,mu,norm,plgndr,alp(nk2,ny)
        integer ix,iy,l,m,fact,ik
        real w(ny),x(ny)
!
!  calculate Gaussian latitudes and weights
!
        call gauleg(-1.0,1.0,x,w,ny)
!
        do iy=1,ny
           lats(iy)=asin(x(iy))*180.0/pi
        enddo
!
        ik=1
        do l=0,lmax+1
        do m=-l,l
           do iy=1,ny
              lat=lats(iy)*pi/180.0
              mu=sin(lat)
              alp(ik,iy)=plgndr(l,abs(m),mu)
           enddo
           ik=ik+1
        enddo
        enddo

!
        return
        end
!
!
!
        subroutine grid2specfft(fieldg,fields,alp,w)
!
        implicit none
        integer lmax,nx,ny,nk,nk2
        real pi
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
!
        real w(ny),fieldg(nx,ny),fields(nk2)
        real alp(nk2,ny),temp(nx),norm,tempg(nx,ny)
        integer ix,iy,ik,l,m
!
        do iy=1,ny
          do ix=1,nx
            temp(ix)=fieldg(ix,iy)
          enddo
          call realft(temp,nx,1)
          do ix=1,nx
            tempg(ix,iy)=temp(ix)
          enddo
        enddo
!
        ik=1
        do l=0,lmax
        do m=-l,l
           norm=2.0*((-1.0)**m)*sqrt(pi/real(ny)) 
           if(m.ne.0)then
             norm=norm/sqrt(2.0)
           else
             norm=norm/2.0
           endif
           fields(ik)=0.0
!
!  have to relate fourier wavenumber m to how the fft subroutine
!  stores output
!
           if(m.gt.0.and.m.lt.nx)then
             ix=2*m+1
           endif
           if(m.lt.0)then
             ix=-2*m+2
           endif
           if(m.eq.0)then
             ix=1
           endif
           if(m.eq.nx)then
             ix=2
           endif 
           do iy=1,ny
             fields(ik)=fields(ik)+                      &
     &         norm*tempg(ix,iy)*w(iy)*alp(ik,iy)
           enddo
           ik=ik+1
        enddo
        enddo
!
!  zero out extra waves
!
        do ik=nk+1,nk2
           fields(ik)=0.0
        enddo
!
        return
        end
!
!
!
        subroutine spec2gridfft(fields,fieldg,alp)
!
!  This subroutine takes the spectral coefficients of a field and returns
!  the gridded field
!
        implicit none
        integer lmax,nx,ny,nk,nk2
        real pi
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
!
        real fieldg(nx,ny),fields(nk2)
        real norm,temp(nx),alp(nk2,ny)
        integer ix,iy,ik,l,m
!
        do ix=1,nx
        do iy=1,ny
          fieldg(ix,iy)=0.0
        enddo
        enddo
!
        ik=1
        do l=0,lmax+1
        do m=-l,l
           norm=2.0*((-1.0)**m)*sqrt(pi/real(ny))
           if(m.ne.0)then
             norm=norm/sqrt(2.0)
           else
             norm=norm/2.0
           endif
!
!  have to relate fourier wavenumber m to how the fft subroutine
!  stores output
!
           if(m.gt.0.and.m.lt.nx)then
             ix=2*m+1
           endif
           if(m.lt.0)then
             ix=-2*m+2
           endif
           if(m.eq.0)then
             ix=1
           endif
           if(m.eq.nx)then
             ix=2
           endif
           do iy=1,ny
               fieldg(ix,iy)=fieldg(ix,iy)+   &
     &           fields(ik)*alp(ik,iy)/norm
           enddo
           ik=ik+1
        enddo
        enddo
!
        do iy=1,ny
          do ix=1,nx
            temp(ix)=fieldg(ix,iy)
          enddo
          call realft(temp,nx,-1)
          do ix=1,nx
            fieldg(ix,iy)=temp(ix)*2.0*pi*2.0/real(nx)
          enddo
        enddo
!
        return
        end
!
!
!
              subroutine realft(data,n,isign)
!C
!C from Numerical Recipes
!C
              integer isign,n
              real data(n)
!            uses four1
!   
!        Calculates the Fourier tranform of a set of n real-valued
!        data points.  Replaces this data (which is stored in the array
!        data(1:n)) by the positive frequency half of its complex Fourier
!        transform.  The real-valued first and last components of the 
!        complex transform are returned as elements data(1) and data(2),
!        respectively.  n must be a power of 2.  This routine also
!        calculates the inverse transform of a complex data array if it
!        is the transform of real data.  (Result in this case must be
!        multiplied by 2/n).  Use isign=1 for forward transform.

              integer i,i1,i2,i3,i4,n2p3
              real c1,c2,h1i,h1r,h2i,h2r,wis,wrs
              double precision theta,wi,wpi,wpr,wr,wtemp
              theta=3.141592653589793d0/dble(n/2)
              c1=0.5
              if (isign.eq.1) then
           c2=-0.5
           call four1(data,n/2,+1)
              else
           c2=0.5
           theta=-theta
              endif
              wpr=-2.0d0*sin(0.5d0*theta)**2
              wpi=sin(theta)
             wr=1.0d0+wpr
              wi=wpi
              n2p3=n+3
              do i=2,n/4
           i1=2*i-1
           i2=i1+1
           i3=n2p3-i2
           i4=i3+1
           wrs=sngl(wr)
           wis=sngl(wi)
           h1r=c1*(data(i1)+data(i3))
           h1i=c1*(data(i2)-data(i4))
           h2r=-c2*(data(i2)+data(i4))
           h2i=c2*(data(i1)-data(i3))
           data(i1)=h1r+wrs*h2r-wis*h2i
           data(i2)=h1i+wrs*h2i+wis*h2r
           data(i3)=h1r-wrs*h2r+wis*h2i
           data(i4)=-h1i+wrs*h2i+wis*h2r
           wtemp=wr
           wr=wr*wpr-wi*wpi+wr
           wi=wi*wpr+wtemp*wpi+wi
        enddo
              if (isign.eq.1) then
           h1r=data(1)
           data(1)=h1r+data(2)
           data(2)=h1r-data(2)
              else
           h1r=data(1)
           data(1)=c1*(h1r+data(2))
           data(2)=c1*(h1r-data(2))
           call four1(data,n/2,-1)
              endif
              return
              end
!
!
!
        subroutine four1(data,nn,isign)
!
! from Numerical Recipes
!
              integer isign,nn
              real data(2*nn)
              integer i,istep,j,m,mmax,n
              real tempi,tempr
              double precision theta,wi,wpi,wpr,wr,wtemp
              n=2*nn
              j=1
              do i=1,n,2
           if(j.gt.i)then
                  tempr=data(j)
                  tempi=data(j+1)
                  data(j)=data(i)
                  data(j+1)=data(i+1)
                  data(i)=tempr
                  data(i+1)=tempi
           endif
           m=n/2
1          if ((m.ge.2).and.(j.gt.m)) then
                  j=j-m
                  m=m/2
                goto 1
           endif
           j=j+m
        enddo
              mmax=2
2             if (n.gt.mmax) then
           istep=2*mmax
           theta=6.28318530717959d0/(isign*mmax)
           wpr=-2.d0*sin(0.5d0*theta)**2
           wpi=sin(theta)
           wr=1.d0
           wi=0.d0
           do m=1,mmax,2
              do i=m,n,istep
                 j=i+mmax
                 tempr=sngl(wr)*data(j)-sngl(wi)*data(j+1)
                 tempi=sngl(wr)*data(j+1)+sngl(wi)*data(j)
                 data(j)=data(i)-tempr
                 data(j+1)=data(i+1)-tempi
                 data(i)=data(i)+tempr
                 data(i+1)=data(i+1)+tempi
              enddo
              wtemp=wr
              wr=wr*wpr-wi*wpi+wr
              wi=wi*wpr+wtemp*wpi+wi
           enddo
           mmax=istep
                 goto 2
              endif
!
              return
        end
!
!
!
        function plgndr(l,m,x)
!C
!C  Numerical Recipes f77 function to calculate the associated Legendre
!C  polynomials
!C
!C  from NR website (ww.nr.com/forum) - improvement of 
!C  of code in book, to better handle large l
!C
!C  These ALP are normalized
!C
        INTEGER l,m
        real plgndr,x
        INTEGER i,ll
        real fact,oldfact,pll,pmm,pmmp1,omx2,PI
        PARAMETER (PI=3.14159265)
!
        if(m.lt.0.or.m.gt.l.or.abs(x).gt.1.)then
           write(6,*) 'bad arguments in plgndr'
           stop
        endif
        pmm=1.
        if(m.gt.0) then
           omx2=(1.-x)*(1.+x)
           fact=1.
           do i=1,m
              pmm=pmm*omx2*fact/(fact+1.)
              fact=fact+2.
           enddo
        endif
        pmm=sqrt((2*m+1)*pmm/(4.*PI))
        if(mod(m,2).eq.1)pmm=-pmm
        if(l.eq.m) then
           plgndr=pmm
        else
           pmmp1=x*sqrt(2.*m+3.)*pmm
           if(l.eq.m+1) then
              plgndr=pmmp1
           else
              oldfact=sqrt(2.*m+3.)
              do ll=m+2,l
                 fact=                                 &
     &             sqrt((4.*ll**2-1.)/(ll**2-m**2)) 
                 pll=(x*pmmp1-pmm/oldfact)*fact
                 oldfact=fact
                 pmm=pmmp1
                 pmmp1=pll
              enddo
              plgndr=pll
           endif
        endif
!
        return
        END
!
!
!
          subroutine gauleg(x1,x2,x,w,n)
!C
!C  Based on Numerical Recipes subroutine gauleg, which
!C  calculates the abscissas and weights for Gaussian integration
!C
            implicit none
            integer i, j, m, n
        real x1,x2,x(n),w(n)
        double precision eps
            parameter (eps=3.D-14)
            double precision p1,p2,p3,pp,xl,xm,z,z1

            m=(n+1)/2
            xm=0.5d0*(x2+x1)
            xl=0.5d0*(x2-x1)
            do i=1,m
                  z1=0.
                  z=COS(3.141592654d0*(i-.25d0)/(n+.5d0))
                  do while ( ABS(z-z1) > EPS)
              p1=1.
              p2=0.
              do j=1,n
                p3=p2
                p2=p1
                p1=((2.*j-1.)*z*p2-(j-1.)*p3)/j
              enddo
              pp=n*(z*p1-p2)/(z*z-1.)
              z1=z
              z=z-p1/pp
           enddo
           x(i)=xm-xl*z
           x(n+1-i)=xm+xl*z
           w(i)=2.*xl/((1.-z*z)*pp*pp)
           w(n+1-i)=w(i)
        enddo
!
        return
        end
!
!
!
        subroutine ddyfft(vars,ddyg,alp,w,lats)
!C
!C  ddy cacluates the meridional derivative using SHs, starting with the spectral form of 
!C  the variable and returning the derivative on the grid (because of the 1/cos(lat) factor)
!C
!C  calls spec2gridfft
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371e6)
!
        real lats(ny),w(ny)
        real varg(nx,ny),vars(nk2)
        real ddyg(nx,ny),ddys(nk2)
        real fac,eta,lat,etalp1,rlp1,rm,rl,rlp2,rlm1
        real alp(nk2,ny)
!
        integer l,m,ik,ik2,ix,iy,iklp1,iklm1
!
!
!
        do l=0,lmax+1   ! extra meridional mode for derivative
        do m=-l,l
!
           rl=real(l)
           rm=real(m)
           eta=sqrt((rl*rl-rm*rm)/(4.0*rl*rl-1.0))
           rlp1=rl+1.0
           rlm1=rl-1.0
           rlp2=rl+2.0
           etalp1=sqrt((rlp1*rlp1-rm*rm)/(4.0*rlp1*rlp1-1.0))
!
           ik=1+(l+1)*l-m         ! index as function of l and m
           iklp1=1+(l+2)*(l+1)-m  ! index for l+1
           iklm1=1+l*(l-1)-m      ! index for l-1
!
           if(l.le.lmax)then
              if(abs(m).lt.l)then
                 ddys(ik)=rlp2*etalp1*vars(iklp1)-rlm1*eta*vars(iklm1)
              else
                 ddys(ik)=rlp2*etalp1*vars(iklp1) ! no l-1 at edges
              endif
           else
              if(abs(m).lt.l)then
                 ddys(ik)=-rlm1*eta*vars(iklm1)
              else
                 ddys(ik)=0.0
              endif
           endif
        
!
        enddo
        enddo
!
        call spec2gridfft(ddys,ddyg,alp)
!
!  still need to multiply by 1/cos(theta) -- note that this could be a problem
!  if we included the poles in our grid and also that this prevents a straightforward
!  spectral representation of the meridional derivative -- two reasons why the 
!  equations are often recast in terms of U=u*cos(theta) and V=v*cos(theta).  
!  It is also convenient
!  that Gaussian integration does not require the endpoints.
!
        do ix=1,nx
        do iy=1,ny
          lat=lats(iy)*pi/180.0
          ddyg(ix,iy) = ddyg(ix,iy)/(re*cos(lat))
        enddo
        enddo
!
        return
        end
!
!
!
        subroutine ddxfft(vars,ddxg,alp,w,lats)
!C
!C  ddx cacluates the zonal derivative using SHs -- input is the variable in
!C  terms of its spectral coefficients, output is on the grid (because the
!C  cos(lat) factor prevents a simple spectral representation)
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371e6)
!
        real alp(nk2,ny),lats(ny),w(ny)
        real varg(nx,ny),vars(nk2)
        real ddxg(nx,ny),ddxs(nk2)
        real fac,lat
!
        integer l,m,ik,ik2,ix,iy
!
        do l=0,lmax+1  ! including extra waves for consistency, but should = 0.0
        do m=-l,l
           if(m.ne.0.0)then
              fac=-real(m)
           else
              fac=0.0
           endif
!
!  In addition to the factor of m that comes from d/dx, there's also
!  a switch from cos to sin and vice versa, which is effected by flipping
!  the sign of m in the referencing index, ik2.  Also note that the derivative
!  of both the sine and cosine have a minus since we defined our sine terms
!  using a -m in the original calculation of the SHs.
!
           ik=1+(l+1)*l-m
           ik2=1+(l+1)*l+m
            ddxs(ik)=fac*vars(ik2)
        enddo
        enddo
!

        call spec2gridfft(ddxs,ddxg,alp)
!
!
!  still need to multiply by 1/cos(theta) -- note that this could be a problem
!  if we included the poles in our grid and also that this prevents a straightforward
!  spectral representation of the meridional derivative -- two reasons why the
!  equations are often recast in terms of U=u*cos(theta) and V=v*cos(theta).  
!  It is also convenient
!  that Gaussian integration does not require the endpoints.
!
        do ix=1,nx
        do iy=1,ny
          lat=lats(iy)*pi/180.0
          ddxg(ix,iy) = ddxg(ix,iy)/(re*cos(lat))
        enddo
        enddo

!
        return
        end
!
!
!
        subroutine vort2psi(vorts,psis)
!C
!C  This subroutine takes the spectral coefficients of vorticity
!C  and returns the spectral coefficients of streamfunction
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
!
        real lats(ny),w(ny)
        real vortg(nx,ny),vorts(nk2),outg(nx,ny)
        real psig(nx,ny),psis(nk2)
        real fac
!
        integer l,m,ik
!
!  inverting the Laplacian is cake in spectral space
!
        ik=1
        do l=0,lmax+1 ! extra modes for consistency, but should be 0.0
        do m=-l,l
           if(l.gt.0)then
              fac=-re*re/(real(l)*real(l+1))
           else
              fac=0.0
           endif
            psis(ik)=fac*vorts(ik)
           ik=ik+1
        enddo
        enddo
!
        return
        end
!
!
!
        subroutine invlap(fields,invlaps)
!C
!C  This subroutine takes the spectral coefficients of a field
!C  and returns the spectral coefficients of the inverse laplacian
!C  of the field
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
!
        real lats(ny),w(ny)
        real fields(nk2),invlaps(nk2)
        real fac
!
        integer l,m,ik
!
!  inverting the Laplacian is cake in spectral space
!
        ik=1
        do l=0,lmax+1 ! extra modes for consistency, but should be 0.0
        do m=-l,l
           if(l.gt.0)then
              fac=-re*re/(real(l)*real(l+1))
           else
              fac=0.0
           endif
           invlaps(ik)=fac*fields(ik)
           ik=ik+1
        enddo
        enddo
!
        return
        end
!

!
!
!
        subroutine makediff(vorts,diffs)
!C
!C  This subroutine takes the spectral coefficients of vorticity
!C  and returns the spectral coefficients of a diffusion term 
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
!
        real lats(ny),w(ny)
        real vortg(nx,ny),vorts(nk2),outg(nx,ny)
        real diffs(nk2)
        real fac,nu
!
        integer l,m,ik
!
        nu=2.5E5
!
        ik=1
        do l=0,lmax+1 ! extra modes for consistency, but should be 0.0
        do m=-l,l
           if(l.gt.0)then
              fac=-real(l)*real(l+1)/(re*re)
           else
              fac=0.0
           endif
           if(l-m.gt.15)then
             diffs(ik)=nu*fac*vorts(ik)
           else
             diffs(ik)=0.0
           endif
           ik=ik+1
        enddo
        enddo
!
        return
        end
!
!
!
        subroutine makeforce(forceg,forces,alp,w,lats)
!C
!C  This subroutine sets the forcing, returning both the gridded form and
!C  the spectral coefficients
!C
!C  Note that the zonal mean of the forcing is removed, following 
!C  Branstator (1985)
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re,nu,ndiff
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(ndiff=1.0) ! order of diffusion
        parameter(nu=2.5E5) ! diffusion constant
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
        parameter(omega=7.292E-5)
!
        real lats(ny),w(ny)
        real forceg(nx,ny),forces(nk2),zav(ny)
        real alp(nk2,ny)
        real diffs(nk2)
        real dl,dp,lon,lon0,lat,lat0,dll,dpp
        real f,d0,dx
!
        integer l,m,ik,ix,iy
!
        dl=30.0
        dp=25.0
        d0=3E-6
        lon0=200.0
        lat0=0.0
        dx=360.0/real(nx)
!
        do ix=1,nx
        do iy=1,ny
          lon=real(ix-1)*dx+dx/2.0
          lat=lats(iy)
          f=2.0*omega*sin(lat*pi/180.0)
          dll=(lon-lon0)*(lon-lon0)/(dl*dl)
          dpp=(lat-lat0)*(lat-lat0)/(dp*dp)
          if(dll+dpp.le.1.0)then
            forceg(ix,iy)=-f*d0*(1-sqrt(dll+dpp))
          else
            forceg(ix,iy)=0.0
          endif
        enddo
        enddo
!
        do iy=1,ny
          zav(iy)=0.0
          do ix=1,nx
             zav(iy)=zav(iy)+forceg(ix,iy)/real(nx)
          enddo
        enddo
!
        do ix=1,nx
        do iy=1,ny
           forceg(ix,iy)=forceg(ix,iy)-zav(iy)
        enddo
        enddo
!
       call grid2specfft(forceg,forces,alp,w)
!
        return
        end
!
!
!
        subroutine makediv(us,vs,divg,alp,w,lats)
!C
!C  This subroutine takes the spectral coefficients of two variables 
!C  and returns the gridded divergence
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
!
        real lats(ny),w(ny),lat
        real us(nk2),vs(nk2),divg(nx,ny)
        real alp(nk2,ny)
        real ddxug(nx,ny),ddyvg(nx,ny),vg(nx,ny)
!
        integer ix,iy
!
        call spec2gridfft(vs,vg,alp)
!
        call ddxfft(us,ddxug,alp,w,lats)
        call ddyfft(vs,ddyvg,alp,w,lats)
!
        do ix=1,nx
        do iy=1,ny
          lat=lats(iy)*pi/180.0
          divg(ix,iy)=ddxug(ix,iy)+ddyvg(ix,iy)+vg(ix,iy)*tan(lat)/re
        enddo
        enddo        
!
        return
        end
!
!
!
!
!
!
        subroutine psi2hgt(psis,hgtg,alp,w,lats)
!C
!C  This subroutine takes the spectral coefficients of streamfunction
!C  and returns the height field, using the linearized balance equation:
!C    g*lap(h)=div(f*grad(psi))
!C
        integer lmax,nx,ny,nk,nk2
        real pi,re,omega,g
!
        parameter(lmax=21) ! max degree of SH, triang. trunc.
        parameter(nk=lmax*(lmax+2)+1) ! number of waves for lmax triang. trunc.
        parameter(nk2=lmax*lmax+4*lmax+4) ! extra modes for merid. deriv.
        parameter(nx=128)
        parameter(ny=64)
        parameter(pi=3.1415927)
        parameter(re=6.371E6)
        parameter(omega=7.292E-5)
        parameter(g=9.8)
!
        real w(ny)
        real psis(nk2),hgtg(nx,ny)
        real fac,f(ny),lat,lats(ny)
        real psig(nx,ny),ddxpsig(nx,ny),ddypsig(nx,ny)
        real ug(nx,ny),vg(nx,ny),us(nk2),vs(nk2)
        real divg(nx,ny),divs(nk2),hgts(nk2)
        real alp(nk2,ny)
!
        integer l,m,ik,ix,iy
!
        do iy=1,ny
            lat=lats(iy)*pi/180.0
            f(iy)=2.0*omega*sin(lat)
        enddo
!
        call ddxfft(psis,ddxpsig,alp,w,lats)        
        call ddyfft(psis,ddypsig,alp,w,lats)
!
        do ix=1,nx
        do iy=1,ny
           ug(ix,iy)=f(iy)*ddxpsig(ix,iy)
           vg(ix,iy)=f(iy)*ddypsig(ix,iy)
        enddo
        enddo
!
        call grid2specfft(ug,us,alp,w)
        call grid2specfft(vg,vs,alp,w)
!
        call makediv(us,vs,divg,alp,w,lats)
!
        call grid2specfft(divg,divs,alp,w)
!
        call invlap(divs,hgts)
!
        call spec2gridfft(hgts,hgtg,alp)
!
        do ix=1,nx
        do iy=1,ny
           hgtg(ix,iy)=hgtg(ix,iy)/g
        enddo
        enddo
!
        return
        end
!
